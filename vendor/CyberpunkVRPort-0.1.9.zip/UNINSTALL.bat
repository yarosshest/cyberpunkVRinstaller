@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo.
echo   CyberpunkVRPort 0.1.9  --  uninstall
echo   =======================================
echo.

rem ---- refuse to run anywhere but the game root ----------------------------------------------
rem Every path below is relative, so in the wrong folder this would delete nothing rather than
rem something -- but saying so beats a run that reports "already gone" 45 times and looks done.
if not exist "bin\x64\Cyberpunk2077.exe" goto :notgameroot

rem ---- and not while the game is running ------------------------------------------------------
rem A locked DLL fails silently enough to leave half a mod behind, and the settings restore below
rem would be overwritten by the running game on exit.
tasklist /fi "imagename eq Cyberpunk2077.exe" 2>nul | find /i "Cyberpunk2077.exe" >nul
if not errorlevel 1 goto :stillrunning

echo   Game folder:  %CD%
echo.
echo   This removes every file CyberpunkVRPort installed -- 43 folders, 80 loose files,
echo   plus the three the plugin writes at runtime.
echo.
echo   See UNINSTALL.txt for the complete removal and settings-restoration instructions.
echo   Your Cyberpunk settings are offered back at the end.
echo.
set "GO="
set /p "GO=  Remove CyberpunkVRPort now? [y/N] "
rem First character only, so y / Y / yes / a stray trailing space all mean yes, and an empty
rem answer (just Enter) does not.
if /i not "!GO:~0,1!"=="y" goto :nothingdone
echo.

set /a GONE=0
set /a ABSENT=0
set /a STUCK=0

call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Basketball"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_BraindanceHud"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Crosshair"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Driving"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_ForceFPP"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_HandCollision"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Holster"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Ladder"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Menu"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Optics"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_PhysicalCrouch"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Reload"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Smoking"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Stereo"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Swimming"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_TacticalBelt"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_VRIK"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_Weapon"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_WorldMap"
call :killdir "bin\x64\plugins\cyber_engine_tweaks\mods\CyberpunkVRPort_WristHud"
call :killdir "r6\scripts\CyberpunkVRPort_Basketball"
call :killdir "r6\scripts\CyberpunkVRPort_BodyCarry"
call :killdir "r6\scripts\CyberpunkVRPort_Cyberware"
call :killdir "r6\scripts\CyberpunkVRPort_DeviceCam"
call :killdir "r6\scripts\CyberpunkVRPort_DualWield"
call :killdir "r6\scripts\CyberpunkVRPort_EngineStereo"
call :killdir "r6\scripts\CyberpunkVRPort_Finisher"
call :killdir "r6\scripts\CyberpunkVRPort_Haptics"
call :killdir "r6\scripts\CyberpunkVRPort_Hold"
call :killdir "r6\scripts\CyberpunkVRPort_Holster"
call :killdir "r6\scripts\CyberpunkVRPort_Melee"
call :killdir "r6\scripts\CyberpunkVRPort_Menu"
call :killdir "r6\scripts\CyberpunkVRPort_NoAnims"
call :killdir "r6\scripts\CyberpunkVRPort_Optics"
call :killdir "r6\scripts\CyberpunkVRPort_PopupVisualState"
call :killdir "r6\scripts\CyberpunkVRPort_ScannerHud"
call :killdir "r6\scripts\CyberpunkVRPort_Smoking"
call :killdir "r6\scripts\CyberpunkVRPort_StoryAttention"
call :killdir "r6\scripts\CyberpunkVRPort_WeaponUp"
call :killdir "r6\scripts\CyberpunkVRPort_WorldMap"
call :killdir "r6\tweaks\vrcigarette"
call :killdir "r6\tweaks\vrport"
call :killdir "red4ext\plugins\CyberpunkVR_Stereo"

call :killfile "archive\pc\mod\cyberpunkvrport.archive"
call :killfile "archive\pc\mod\cyberpunkvrport.archive.xl"
call :killfile "bin\x64\CyberpunkVR_LighterGrip_Left.ini"
call :killfile "bin\x64\CyberpunkVR_RestGrip_Left.ini"
call :killfile "bin\x64\CyberpunkVR_RestGrip_Right.ini"
call :killfile "bin\x64\CyberpunkVR_SmokeGrip_Left.ini"
call :killfile "bin\x64\CyberpunkVR_SmokeGrip_right.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_achilles.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_achilles@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_ajax.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_ajax@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_ashura.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_bat.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_buck.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_burya.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_carnage.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_chao.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_copperhead.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_copperhead@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_crusher.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_crusher@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_defender.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_dian.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_dian@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_grad.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_grad@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_guillotine.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_guillotine@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_hammer.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_hercules.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_hercules@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_igla.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_itemspreset_katana_takemura.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kanabo.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kappa.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_katana.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kenshin.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kolac.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kolac@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kyubi.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_kyubi@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_lexington.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_liberty.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_masamune.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_masamune@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_nekomata.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_nekomata@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_nova.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_nue.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_omaha.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_osprey.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_osprey@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_overture.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_pozhar.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_pozhar@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_pulsar.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_pulsar@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_quasar.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_rasetsu.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_rocketlauncher.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_saratoga.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_saratoga@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_senkoh.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_senkoh@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_shingen.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_sidewinder.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_sidewinder@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_silverhand.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_sor22.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_sor22@mag.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_tactician.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_tamayura.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_testera.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_unity.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_warden.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_yukimura.ini"
call :killfile "bin\x64\CyberpunkVR_TwoHandGrip_zhuo.ini"
call :killfile "bin\x64\openvr_api.dll"
call :killfile "engine\config\platform\pc\vrcam_cpu_tweaks.ini"
call :killfile "r6\input\CyberpunkVRPort_ScannerHud.xml"

call :killfile "bin\x64\vrport.ini"
call :killfile "bin\x64\vrport-launcher.ini"
call :killfile "bin\x64\cyberpunkvrport.log"

echo.
echo   Removed !GONE!, already gone !ABSENT!, could not remove !STUCK!.
if !STUCK! GTR 0 (
  echo.
  echo   Something is holding those files. Close the game and Steam and run this again.
)

rem ---- offer the player's own settings back ---------------------------------------------------
rem The newest backup, because the plugin only ever writes one and only on a first launch, but a
rem reinstall makes a second and the newest is the one from the install being removed.
set "CFG=%LOCALAPPDATA%\CD Projekt Red\Cyberpunk 2077"
set "BAK="
for /f "delims=" %%F in ('dir /b /o-d "%CFG%\UserSettings.pre-vr-*.json" 2^>nul') do (
  if not defined BAK set "BAK=%%F"
)
if not defined BAK goto :nobackup

echo.
echo   Your own Cyberpunk settings were saved before this mod applied its VR preset:
echo     !BAK!
set "GO2="
set /p "GO2=  Put them back now? [y/N] "
if /i not "!GO2:~0,1!"=="y" (
  echo   Left alone. It is still there whenever you want it.
  goto :done
)
copy /y "%CFG%\!BAK!" "%CFG%\UserSettings.json" >nul
if errorlevel 1 (
  echo   FAILED. Do it by hand: rename
  echo       %CFG%\!BAK!
  echo       over UserSettings.json
) else (
  echo   Restored. Your graphics, comfort and language settings are yours again.
)
goto :done

:nobackup
echo.
echo   No UserSettings.pre-vr-*.json found in
echo     %CFG%
echo   So either the VR preset was never applied, or the backup has been moved.
goto :done

:done
echo.
echo   Done. UNINSTALL.txt is still here if you want to check anything by hand --
echo   delete it, INSTALL.txt and this file whenever you like.
echo.
pause
exit /b 0

:notgameroot
echo   This is not the Cyberpunk 2077 folder:
echo     %CD%
echo.
echo   bin\x64\Cyberpunk2077.exe is not here. UNINSTALL.bat belongs in the game root --
echo   the folder that holds bin\, r6\, red4ext\ and archive\ -- and has to run there.
echo.
pause
exit /b 1

:stillrunning
echo   Cyberpunk 2077 is running.
echo.
echo   Close it first: the plugin DLL is locked while the game is up, and the game
echo   rewrites its settings file on exit, which would undo the restore below.
echo.
pause
exit /b 1

:nothingdone
echo.
echo   Nothing was deleted.
echo.
pause
exit /b 0

rem ---- helpers, past every exit so nothing falls into them ------------------------------------
:killdir
if not exist "%~1\" (
  set /a ABSENT+=1
  exit /b 0
)
rmdir /s /q "%~1" 2>nul
if exist "%~1\" (
  echo   LOCKED      %~1\
  set /a STUCK+=1
) else (
  echo   removed     %~1\
  set /a GONE+=1
)
exit /b 0

:killfile
if not exist "%~1" (
  set /a ABSENT+=1
  exit /b 0
)
del /f /q "%~1" 2>nul
if exist "%~1" (
  echo   LOCKED      %~1
  set /a STUCK+=1
) else (
  echo   removed     %~1
  set /a GONE+=1
)
exit /b 0
